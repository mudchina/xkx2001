// Room: /d/beijing/east/andingmenlou.c

inherit ROOM;

void create()
{
	set("short", "�����ų�¥");
	set("long", @LONG
����һ��ʲ��Ҳû�еĿշ��䡣
LONG
	);
	set("exits", ([ /* sizeof() == 3 */
  "west" : __DIR__"chengqiang1",
  "down" : __DIR__"andingmen",
  "east" : __DIR__"chengqiang2",
]));
	set("no_clean_up", 0);

	setup();
	replace_program(ROOM);
}
