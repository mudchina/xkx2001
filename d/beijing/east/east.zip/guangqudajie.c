// Room: /d/beijing/east/guangqudajie.c

inherit ROOM;

void create()
{
	set("short", "�����Ŵ��");
	set("long", @LONG
����һ��ʲ��Ҳû�еĿշ��䡣
LONG
	);
	set("exits", ([ /* sizeof() == 4 */
  "northeast" : __DIR__"dongbianmen",
  "south" : __DIR__"zuoanmen",
  "north" : __DIR__"chongwendajie",
  "east" : __DIR__"guangqumen",
]));
	set("no_clean_up", 0);

	setup();
	replace_program(ROOM);
}
