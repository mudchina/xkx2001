// Room: /d/beijing/east/chengqiang4.c

inherit ROOM;

void create()
{
	set("short", "��ǽ");
	set("long", @LONG
����һ��ʲ��Ҳû�еĿշ��䡣
LONG
	);
	set("exits", ([ /* sizeof() == 3 */
  "north" : __DIR__"zhaoyangmenlou",
  "west" : __DIR__"chongwenmenlou",
  "east" : __DIR__"dongbianmenlou",
]));
	set("no_clean_up", 0);

	setup();
	replace_program(ROOM);
}
