// Room: /d/beijing/east/gongyuan.c

inherit ROOM;

void create()
{
	set("short", "��Ժ");
	set("long", @LONG
����һ��ʲ��Ҳû�еĿշ��䡣
LONG
	);
	set("exits", ([ /* sizeof() == 1 */
  "west" : __DIR__"wangfudajie3",
]));
	set("no_clean_up", 0);

	setup();
	replace_program(ROOM);
}
