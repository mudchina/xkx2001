// Room: /d/beijing/east/dongzhidajie2.c

inherit ROOM;

void create()
{
	set("short", "��ֱ�Ŵ��");
	set("long", @LONG
����һ��ʲ��Ҳû�еĿշ��䡣
LONG
	);
	set("exits", ([ /* sizeof() == 3 */
  "north" : __DIR__"zhongtianlou",
  "west" : "/d/beijing/west/gulou",
  "east" : __DIR__"dongzhidajie",
]));
	set("no_clean_up", 0);

	setup();
	replace_program(ROOM);
}
