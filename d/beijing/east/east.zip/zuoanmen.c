// Room: /d/beijing/east/zuoanmen.c

inherit ROOM;

void create()
{
	set("short", "����");
	set("long", @LONG
����һ��ʲ��Ҳû�еĿշ��䡣
LONG
	);
	set("exits", ([ /* sizeof() == 2 */
  "up" : __DIR__"zuoanmenlou",
  "north" : __DIR__"guangqudajie",
]));
	set("no_clean_up", 0);

	setup();
	replace_program(ROOM);
}
