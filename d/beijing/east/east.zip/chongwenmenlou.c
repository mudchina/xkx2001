// Room: /d/beijing/east/chongwenmenlou.c

inherit ROOM;

void create()
{
	set("short", "�����ų�¥");
	set("long", @LONG
����һ��ʲ��Ҳû�еĿշ��䡣
LONG
	);
	set("exits", ([ /* sizeof() == 3 */
  "west" : __DIR__"chengqiang5",
  "down" : __DIR__"chongwenmen",
  "east" : __DIR__"chengqiang4",
]));
	set("no_clean_up", 0);

	setup();
	replace_program(ROOM);
}
