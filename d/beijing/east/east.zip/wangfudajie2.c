// Room: /d/beijing/east/wangfudajie2.c

inherit ROOM;

void create()
{
	set("short", "�������");
	set("long", @LONG
����һ��ʲ��Ҳû�еĿշ��䡣
LONG
	);
	set("exits", ([ /* sizeof() == 4 */
  "west" : __DIR__"donghuamen",
  "south" : __DIR__"wangfudajie3",
  "north" : __DIR__"wangfudajie",
  "east" : __DIR__"yumaquan",
]));
	set("no_clean_up", 0);

	setup();
	replace_program(ROOM);
}
