// Room: /d/beijing/east/chengqiang2.c

inherit ROOM;

void create()
{
	set("short", "��ǽ");
	set("long", @LONG
����һ��ʲ��Ҳû�еĿշ��䡣
LONG
	);
	set("exits", ([ /* sizeof() == 2 */
  "south" : __DIR__"dongzhimenlou",
  "west" : __DIR__"andingmenlou",
]));
	set("no_clean_up", 0);

	setup();
	replace_program(ROOM);
}
