// Room: /d/beijing/east/zhongtianlou.c

inherit ROOM;

void create()
{
	set("short", "������¥");
	set("long", @LONG
����һ��ʲ��Ҳû�еĿշ��䡣
LONG
	);
	set("exits", ([ /* sizeof() == 3 */
  "south" : __DIR__"dongzhidajie2",
  "north" : __DIR__"andingmen",
  "east" : __DIR__"guozijian",
]));
	set("no_clean_up", 0);

	setup();
	replace_program(ROOM);
}
