inherit ROOM;

void create()
{
    set("short", "���");
	set("long",  @LONG
LONG
	);

	set("exits", ([
        "north" : __DIR__"shouango",
        "south"  : __DIR__"shoukang",
	]));

	set("outdoors","beijing");
	setup();
	replace_program(ROOM);
}
