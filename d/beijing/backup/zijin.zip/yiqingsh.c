// Room: /d/beijing/qianqing/yangxindian.c

inherit ROOM;

void create()
{
    set("short", "��������");
	set("long", @LONG

LONG
	);
	set("exits", ([ /* sizeof() == 2 */
  "south" : __DIR__"changchu",
]));
	set("no_clean_up", 0);
	set("exit", "e");

	setup();
	replace_program(ROOM);
}
