inherit ROOM;

void create()
{
    set("short", "�����");
	set("long",  @LONG
LONG
	);

	set("exits", ([
        "south" : __DIR__"cininggo",
	]));

	set("outdoors","beijing");
	setup();
	replace_program(ROOM);
}
