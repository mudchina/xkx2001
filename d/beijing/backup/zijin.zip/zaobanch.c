inherit ROOM;

void create()
{
    set("short", "��촦");
	set("long",  @LONG
    ������.
LONG
	);

	set("exits", ([
		"east" : __DIR__"youyimen",
        "west" : __DIR__"cininghu",
	]));

	set("outdoors","beijing");
	setup();
	replace_program(ROOM);
}
