inherit ROOM;

void create()
{
    set("short", "�����");
	set("long",  @LONG
LONG
	);

	set("exits", ([
        "south"     : __DIR__"zhaigong",
        "north"     : __DIR__"jingreng",
	]));

	setup();
	replace_program(ROOM);
}
