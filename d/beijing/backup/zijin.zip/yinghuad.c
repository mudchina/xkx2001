inherit ROOM;

void create()
{
    set("short", "Ӣ����");
	set("long",  @LONG
   ������.
LONG
	);

	set("exits", ([
        "north" : __DIR__"tongdao8",
        "south"  : __DIR__"shouango",
	]));

	set("outdoors","beijing");
	setup();
	replace_program(ROOM);
}
