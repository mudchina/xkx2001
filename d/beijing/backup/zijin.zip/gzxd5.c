inherit ROOM;

void create()
{
    set("short", "����С��");
	set("long",  @LONG
LONG
	);

	set("exits", ([
        "north" : __DIR__"huayuan",
        "southeast" : __DIR__"ningshou",
        "northeast" : __DIR__"yangxinm",
	]));
	set("outdoors","beijing");
	setup();
	replace_program(ROOM);
}
