inherit ROOM;

void create()
{
    set("short", "ͬ˳ի");
	set("long",  @LONG
LONG
	);

	set("exits", ([
        "south" : __DIR__"yonghego",
	]));

	set("outdoors","beijing");
	setup();
	replace_program(ROOM);
}
