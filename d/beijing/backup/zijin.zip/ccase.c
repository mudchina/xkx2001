#include <stdio.h>
#include <stdlib.h>

int main()
{
	char filename[100];
	char lcase[100];
	char command[100];
	int i;
	FILE *fp;

	system("ls -1 *.C > dir.tmp");
	if ((fp=fopen("dir.tmp","rt")) == NULL)
	{
		printf("Can't open dir.tmp\n");
		exit(1);
		}

	while (fscanf(fp, "%s\n",filename) != EOF)
	{
		for (i=0; i<strlen(filename); i++)
			lcase[i] = tolower(filename[i]);

		lcase[i] = '\0';
		sprintf(command, "cp %s %s",
			filename, lcase);
		printf("%s\n",command);
		system(command);
		}

	fclose(fp);
	return 0;
	}
