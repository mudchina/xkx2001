inherit ROOM;

void create()
{
    set("short", "�ٰ���");
	set("long",  @LONG
    ������.
LONG
	);

	set("exits", ([
        "north" : __DIR__"yinghuad",
        "south"  : __DIR__"houdian",
	]));

	set("outdoors","beijing");
	setup();
	replace_program(ROOM);
}
