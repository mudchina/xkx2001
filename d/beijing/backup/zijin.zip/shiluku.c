inherit ROOM;

void create()
{
    set("short", "ʵ¼��");
	set("long",  @LONG
LONG
	);

	set("exits", ([
        "west"  : __DIR__"hongbenk",
	]));

	setup();
	replace_program(ROOM);
}
