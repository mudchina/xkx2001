inherit ROOM;

void create()
{
    set("short", "�ٿ���");
	set("long",  @LONG
    ������.
LONG
	);

	set("exits", ([
        "north" : __DIR__"houdian",
        "east"  : __DIR__"cininggo",
	]));

	set("outdoors","beijing");
	setup();
	replace_program(ROOM);
}
