// Room: /d/beijing/qianqing/qianqingmen.c

inherit ROOM;

void create()
{
    set("short", "���鷿");
	set("long", @LONG
    ���ǻ����Ƕ�������鷿.
LONG
	);
	set("exits", ([ /* sizeof() == 2 */
  "east" : __DIR__"sikongch",
  "west"  : __DIR__"qianqmen",
]));
	set("no_clean_up", 0);
	set("outdoors", "beijing");

	setup();
	replace_program(ROOM);
}
